# Sim Economie

Bienvenue dans **Sim Economie**, un jeu de gestion, d'entreprenariat et de simulation d'économie réaliste.

## 💰 À propos

Sim Economie est un jeu de simulation économique où vous pouvez gérer votre entreprise, investir en bourse, trader des cryptomonnaies et bien plus encore. Le jeu vise à offrir une expérience réaliste tout en restant divertissant.

## ✨ Caractéristiques

- 📊 Simulation économique réaliste
- 💼 Gestion d'entreprise et entreprenariat
- 📈 Multiples mécaniques de jeu (bourse, crypto, et plus)
- 🎮 Développé en C# avec Windows Forms (sans moteur de jeu)
- 🇫🇷 Interface en français

## 🚀 Installation

### Prérequis
- .NET 6.0 ou supérieur
- Windows

### Lancer le jeu
```bash
dotnet run
```

Ou compiler et exécuter :
```bash
dotnet build
cd bin/Debug/net6.0-windows
./Jeu.exe
```

## 📖 Comment jouer

Consultez le fichier `tutoriel.md` pour apprendre à jouer.

## 📝 Mises à jour

Consultez le fichier `changelog.md` pour voir l'historique des modifications.

**Version actuelle :** v0.0.1 ALPHA

## 📂 Structure du projet

```
Sim Economie/
├── Program.cs              # Point d'entrée
├── MenuPrincipal.cs        # Menu principal
├── FenetreJeu.cs          # Fenêtre de jeu
├── FenetreSauvegarde.cs   # Gestion des sauvegardes
├── Jeu.csproj             # Configuration du projet
├── README.md              # Ce fichier
├── changelog.md           # Historique des versions
└── tutoriel.md            # Guide du joueur
```

## 📧 Contact

- **Discord:** SqerstersTheYT
- **Email:** sqersterspromail@gmail.com

## 📜 Licence

Non open-source - Accès public pour jouer

---

© 2024 Sim Economie - Tous droits réservés
