# Changelog - Sim Economie

## Système de versioning

- **0.0.X** - Petites mises à jour (corrections, petites améliorations)
- **0.X.0** - Mises à jour normales (nouvelles fonctionnalités)
- **X.0.0** - Mises à jour majeures (changements importants)

---

## Version 0.0.1 - 11 novembre 2024

### ✨ Nouveautés
- **Menu principal** avec interface graphique Windows Forms
- Design économique professionnel avec thème bourse/finance
- 3 boutons principaux :
  - 💼 Nouvelle Partie (non fonctionnel pour le moment)
  - 💾 Charger Partie (non fonctionnel pour le moment)
  - 🚪 Quitter
- Indicateurs de devises en temps réel (USD, EUR, BTC)
- Effets visuels : symboles monétaires, motifs de billets, dégradés
- Architecture multi-fichiers (Program.cs, MenuPrincipal.cs, FenetreJeu.cs, FenetreSauvegarde.cs)

### 📝 Notes
- Version ALPHA initiale
- Fonctionnalités de jeu à venir dans les prochaines versions

---

## Idées de futur update

### 0.0.2
- Amélioration de l'interface utilisateur
- Ajout de statistiques de base (argent, temps de jeu)

### 0.0.3
- Corrections de bugs mineurs
- Optimisation des performances

### 0.0.4
- Ajout de sons d'interface
- Amélioration du tutoriel

